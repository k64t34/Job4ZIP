﻿'
' Сделано в SharpDevelop.
' Пользователь: skorik
' Дата: 17.05.2013
' Время: 10:46
' 
' Для изменения этого шаблона используйте Сервис | Настройка | Кодирование | Правка стандартных заголовков.

'
Imports System.Xml
Imports System.Linq
Imports System.XML.Linq
Imports System.Boolean
Imports System.Net.Mail
Imports System.Security.Cryptography
 
Module Program	
	Dim XmlDoc As XDocument
	Dim xmlFile As String
	Dim fso As Object
	Sub Main(ByVal args() As String)
	Dim StartTime,FinishTime As DateTime	
	'Sub Main()		
		StartTime=Now()
		Console.BackgroundColor = ConsoleColor.White
		Console.ForegroundColor = ConsoleColor.Black
		Console.Clear		
		Console.Title="Job for 7-Zip"
		Console.WriteLine(Console.Title)
		Console.WriteLine("------------------------------------------------------- by Skorik 2013")		
		Dim path_7z,SourcePath,TargetPath,TargetFile,_7z_cmd,TargetFileSuffix,IncludeFile,ExcludeFile,JobName As String		
		Dim ArcCount As Integer		
		fso = CreateObject("Scripting.FileSystemObject")
		'
		'Parsing arguments command line
		'
		If args.Length=0 Then
			xmlFile=AppDomain.CurrentDomain.BaseDirectory & "job7zip.xml"
		Else
			xmlFile=args(0)
		End If
        'For i As Integer = 0 To args.Length - 1
        'Console.WriteLine("Arg: " & i & " is """ & args(i) & """")
        'Next
        Console.WriteLine("Config file is "&xmlFile)
        If Not fso.FileExists(xmlFile) Then
        	Console.WriteLine("ERR: Config File """+xmlFile+""" not exist")
        	Console.ReadKey(True)
			Exit Sub 
        End If        
        '
        ' Parsing config file
        '
        Try         
        	XmlDoc = XDocument.Load(xmlFile)
        Catch ex As Exception
        	Console.WriteLine("ERR: Config File """+xmlFile+""" not parsing")
        	Console.ReadKey(True)
			Exit Sub 
        End Try
        If Not ReadPathFromConfig(SourcePath,"SourcePath") Then
        	Console.ReadKey(True)
        	Exit Sub 
        End If	
        ReadPathFromConfig(TargetPath,"TargetPath")        
        If Not fso.FolderExists(TargetPath) Then
			Console.WriteLine("WARN: Folder """+TargetPath+""" not exist. Creating folder... ")
			try 
				fso.CreateFolder(TargetPath)
			Catch ex As Exception
				Console.WriteLine("ERR: Failed to create a folder """+TargetPath+"""")
				Console.ReadKey(True)
				Exit Sub 
			End Try
			
			If Not fso.FolderExists(TargetPath) Then
				Console.WriteLine("ERR: Failed to create a folder """+TargetPath+"""")
				Console.ReadKey(True)
				Exit Sub 
			End If			
		End If		
		
		
		ReadStringFromConfig(JobName ,"JobName")
		Console.WriteLine("JobName="+JobName)
		ReadStringFromConfig(TargetFile ,"TargetFile")
		Console.WriteLine("TargetFile="+TargetFile)
		ReadStringFromConfig(TargetFileSuffix ,"TargetFileSuffix")
		Console.WriteLine("TargetFileSuffix="+TargetFileSuffix)
		ReadStringFromConfig(IncludeFile ,"IncludeFile")
		Console.WriteLine("IncludeFile="+IncludeFile)				
		ReadStringFromConfig(ExcludeFile ,"ExcludeFile")
		Console.WriteLine("ExcludeFile="+ExcludeFile)			
		ReadIntegerFromConfig(ArcCount,"ArcCount")
		Console.WriteLine("ArcCount={0}",ArcCount)			
		path_7z="C:\Program Files\7-Zip\"				
		If Not fso.FolderExists(path_7z) Then
			Console.WriteLine("ERR: Folder """+path_7z+""" not exist")
			Console.ReadKey(True)
			Exit Sub 
		End If
		path_7z=path_7z+"7z.exe"
		If Not fso.FileExists(path_7z) Then
			Console.WriteLine("ERR: File """+path_7z+""" not exist")
			Console.ReadKey(True)
			Exit Sub 
		End If		
		'
		' Подсчитать занимаемое место сорспапки и проверить свободное мест на целевом диске.
		'
		
		'		'
		' Create tmp files
		'
		'If ExcludeFile<>"" then 
		Console.WriteLine("include")
		Dim incFile=fso.GetTempName()		
		Dim HincFile =My.Computer.FileSystem.OpenTextFileWriter(incFile, True,System.Text.Encoding.UTF8)
		Dim split As String() = IncludeFile.Split(";")
        For Each s As String In  split
        	If s.Trim() <> "" Then     
        		HincFile.WriteLine(SourcePath+s)        		
        		Console.WriteLine(SourcePath+s)
            End If 
        Next s  
        HincFile.Close
				
		Console.WriteLine("exclude")
		Dim ExcFile=fso.GetTempName()
		Erase split
		
		HincFile =My.Computer.FileSystem.OpenTextFileWriter(ExcFile, True,System.Text.Encoding.UTF8)
		If ExcludeFile<>"" then
			split = ExcludeFile.Split(";")			
	        For Each s As String In  split
	            If s.Trim() <> "" Then            	
	            	HincFile.WriteLine(s)
	            	Console.WriteLine(s)
	            End If 
	        Next s
	    end if    
        HincFile.Close
        
        '
        ' Проверить что все файлы закрыты
        '
        
		'
		'Run 7z
		'
		'
		_7z_cmd="a"			
		Dim p As New ProcessStartInfo
		p.FileName = path_7z	
		'p.Arguments = _7z_cmd+" -r -mx9 -ms=off -mtc=on """+target_path+target_file+""" """+source_path+"*"""	
		'p.Arguments = _7z_cmd+" -r -mx9  """+TargetFile+""" """+SourcePath+"*"""	
		Dim TargetFileFullName=TargetFile+"_("+Format(Now,TargetFileSuffix) +").7z"
		p.Arguments = _7z_cmd+" -r -mx9 -i@"+incFile+" -x@"+ExcFile+" """+TargetPath+TargetFileFullName+""" "
		p.WindowStyle = ProcessWindowStyle.Normal
		Dim myProcess As Process = Nothing
		Try
		Console.WriteLine(p.FileName+" "+p.Arguments)
		myProcess =Process.Start(p)	
		Catch e As FormatException
		End Try
		do
		Loop While Not myProcess.WaitForExit(1000)
		Console.WriteLine("Process exit code: {0}", myProcess.ExitCode)
		fso.deletefile(incFile)
		If fso.FileExists(ExcFile) Then 
			fso.deletefile(ExcFile) 
		end if
		If myProcess.ExitCode=0 Then
			'
			' Find Old Archive
			'			
			Dim ff=fso.GetFolder(TargetPath)
			Dim curArcCount=0		
			Dim strlen_target_file=Len(TargetFile)+1
			For Each  fil In ff.files
				'Console.WriteLine(Fil.Name)			
				'Console.WriteLine(Left(Fil.Name,strlen_target_file)+":"+TargetFile+"_")			
				If 	Left(Fil.Name,strlen_target_file)=TargetFile+"_" Then				
					'Console.WriteLine(curArcCount)
					Dim filDate
					filDate=Mid(Fil.Name,strlen_target_file+2,Len(Fil.Name)-strlen_target_file-5)				
					'Console.WriteLine(filDate)
					Try
						If IsDate(DateTime.ParseExact(filDate, TargetFileSuffix, Nothing)) Then
							curArcCount=curArcCount+1
						End if	
					Catch e As FormatException
	         			'Console.WriteLine("{0} is not in the correct format.", filDate)
	      			End Try 	
						
				End If
			Next
			'
			' If Count of old archive more ArcCount then delete older archive
			'
			If curArcCount-1>ArcCount	Then
				Dim fl_Name() As String
				Dim fl_Date() As Date
				curArcCount=0
				For Each  fil In ff.files				
	    			If 	Left(fil.name,strlen_target_file)=TargetFile+"_" Then
						Dim filDate
						filDate=Mid(fil.name,strlen_target_file+2,Len(fil.name)-strlen_target_file-5)				
						Try					
							If IsDate(DateTime.ParseExact(filDate, TargetFileSuffix, Nothing)) Then
								ReDim Preserve fl_Name(curArcCount)
								fl_Name(curArcCount)=fil.name
								ReDim Preserve fl_Date(curArcCount)
								fl_Date(curArcCount)=DateTime.ParseExact(filDate, TargetFileSuffix, Nothing)
								'Console.WriteLine(CStr(curArcCount)+". "+fl_Date(curArcCount)+" "+fl_Name(curArcCount))
								curArcCount=curArcCount+1
							End if	
						Catch e As FormatException
		         			'Console.WriteLine("{0} is not in the correct format.", filDate)
						End Try 
					End if	
				Next
				If curArcCount>0 Then 
					Array.Sort(fl_Date)				
					Dim i=0
					while i<=curArcCount-ArcCount-2 
						ExcFile=TargetPath+TargetFile+"_("+Format(fl_Date(i),TargetFileSuffix) +").7z"
						Console.WriteLine("Delete old archive "+ExcFile)
						fso.deletefile(ExcFile)					
						i=i+1
					End While
				End if
			End If
		End If		
		FinishTime=Now()
		'
		' System Log
		'		
		Dim LogText As String = "Job7zip complit job "+xmlFile
		If myProcess.ExitCode=0 Then
			LogText=LogText+" sucess"
		Else
			LogText=LogText+" with error"+CStr(myProcess.ExitCode)
		End if
		Dim sSource As String
		sSource = "Job7zip"
		Dim sLog As String
		sLog = "Application"
		If Not EventLog.SourceExists(sSource) Then
    		EventLog.CreateEventSource(sSource, sLog)
		End If		
		EventLog.WriteEntry(sSource, LogText)	
		
		'
		' Send Mail
		'http://social.msdn.microsoft.com/Forums/en-US/vblanguage/thread/f040bf19-6474-421c-958b-7aa19973b328/
		Dim Mail As New MailMessage
		Dim tmpMailString As String
		Dim tmpMailInt As Integer
        Try
        	ReadStringFromConfig(tmpMailString,"EmailFrom")
        	Mail.From =New MailAddress(tmpMailString)
        	'Console.WriteLine("from={0}",Mail.From.ToString)
        	ReadStringFromConfig(tmpMailString,"EmailTo")
        	
        	split  = tmpMailString.Split(";")
        	For Each s As String In  split
        		If s.Trim() <> "" Then     
        			Mail.To.Add(s)    
        			'Console.WriteLine("Mail To: {0}",s)
            	End If 
        	Next s  
        	
            Mail.Subject = JobName
            Mail.Body =JobName+" завершено"
            If myProcess.ExitCode=0 Then
            	Mail.Body =Mail.Body +" успешно."
            
            Else	
            	Mail.Body =Mail.Body +" c ошибкой. Код ошибки "+CStr(myProcess.ExitCode)+"."
            End If
            If fso.FileExists(TargetPath+TargetFileFullName) Then 
            	Dim TargetFileFullName_Info As New IO.FileInfo(TargetPath+TargetFileFullName)          	
            	Mail.Body =Mail.Body +vbCrLf+"Создан файл "+TargetPath+TargetFileFullName+" размером "+FormatByte(TargetFileFullName_Info.Length)
            	Mail.Body =Mail.Body +vbCrLf+"по заднию "+xmlFile+"."
            Else	
            	Mail.Body =Mail.Body +vbCrLf+"по заднию "+xmlFile+" файл не создан."
            End If
            '-> Добавить расчет свободного места для сетевых накопителей
        	Dim cdrive As System.IO.DriveInfo
        	cdrive = My.Computer.FileSystem.GetDriveInfo(TargetPath)
        	Mail.Body =Mail.Body +vbCrLf+"Свободного места на диске осталось "+FormatByte(cdrive.TotalFreeSpace)           	
            Mail.Body =Mail.Body +vbCrLf+"Задание выполнялось с "+Format(StartTime,"HH:mm")+" по "+  Format(FinishTime,"HH:mm")+". Длилось "+Format(DateDiff("n",FinishTime,StartTime)) 
            
            ReadStringFromConfig(tmpMailString,"EmailServer")
            Dim SMTP As New SmtpClient(tmpMailString)
            SMTP.EnableSsl = False
            ReadIntegerFromConfig(tmpMailInt,"EmailPort")
            SMTP.Port = tmpMailInt
            Dim EmailPassword As String
            ReadStringFromConfig(EmailPassword,"EmailPassword")
            
            If EmailPassword<>"" Then
            	' ->Сделать шифрование паролей
	            'Dim wrapper As New Simple3Des("09071903")
	        	'Dim cipherText As String '= wrapper.EncryptData("09071903")
		        'ReadStringFromConfig(cipherText ,"EmailPassword")
		        'Console.WriteLine(cipherText)
		        'SMTP.Credentials = New System.Net.NetworkCredential(Mail.From.ToString, EmailPassword)
		        'Try
		        	'EmailPassword= wrapper.DecryptData(cipherText)
		        	'Console.WriteLine(EmailPassword)
		        	
		    	'Catch ex As System.Security.Cryptography.CryptographicException        	
		    	'End Try             
		    	'
            Else
            	SMTP.Credentials = New System.Net.NetworkCredential()
            End If	    	
            
            Console.WriteLine("Send email...")
            SMTP.Send(Mail)
        Catch  ex As Exception
        	'->Изменить значек события и код возврата
        	Console.WriteLine("job4zip can't send email "+ex.Message)
        	EventLog.WriteEntry(sSource, "job4zip can't send email "+ex.Message)	
        End Try
        
        
        'Console.ReadKey(True)
        
        
	End Sub
	'*************************************************
	Function ReadPathFromConfig(ByRef var As String,argName As String)
		'*************************************************
		ReadStringFromConfig(var, argName)		
		If Not Strings.Right(var,1)="\" Then
			var=var+"\"
		End If
		Console.WriteLine(argName+"=" & var)
		ReadPathFromConfig=true
		If Not fso.FolderExists(var) Then
			Console.WriteLine("ERR: Folder """+var+""" not exist")
			ReadPathFromConfig=False						
		End If	
	End Function
	'*************************************************
	Function ReadStringFromConfig(ByRef var As String ,argName As String)
	'*************************************************		
	Dim myel =From el In XmlDoc.<JOB>.Elements()  Where el.Name=argName Select el		 
		var=myel.value   
		If Strings.Left(var,1)="""" Then
			If Strings.Right(var,1)="""" Then
				var=Strings.Mid(var,2,Strings.Len(var)-2)
			End If
		End If
	ReadStringFromConfig=len(var)<>0
	End Function
	'*************************************************
	Function ReadIntegerFromConfig(ByRef var As Integer ,argName As String)
	'*************************************************		
	Dim StrVar As String
	ReadStringFromConfig(StrVar, argName)
	ReadIntegerFromConfig=IsNumeric(StrVar)
	If ReadIntegerFromConfig Then
		var=CInt(StrVar)
	End If
	End Function
	
	'*************************************************
	Function FormatByte(bytes As Long)
	'*************************************************		
	FormatByte=""
	Dim ByteName="байт"
	If	bytes>= 1099511627776 then
		bytes=bytes/1099511627776	
		ByteName="Т"+ByteName
		
	ElseIf	bytes>= 1073741824
		bytes=bytes/1073741824	
		ByteName="Г"+ByteName
	ElseIf	bytes>= 1048576
		bytes=bytes/1048576	
		ByteName="М"+ByteName
	ElseIf	bytes>= 1024
		bytes=bytes/1024
		ByteName="К"+ByteName
	End If
	FormatByte=Format(bytes,"### ##0")+" "+ByteName
	
	End Function

End Module


'->Добавить расчет времени на упаковку и средней скорости архивированаия
